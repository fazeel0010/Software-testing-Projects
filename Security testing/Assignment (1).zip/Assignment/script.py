import sys
import requests

# Define the URLs of the pages to test
pages = {
	"echo.php":"http://localhost:9000/echo.php?name=localhost",
	"echo-name.php":"http://localhost:9000/echo-name.php?name=localhost",
    	"ping.php":"http://localhost:9000/ping.php?host=localhost",
    	"ping-no-pipe.php":"http://localhost:9000/ping-no-pipe.php?host=localhost",
    	"ping-no-amp.php":"http://localhost:9000/ping-no-amp.php?host=localhost",
#    	"ping-no-output.php":"http://localhost:9000/ping-no-output.php?host=localhost",
    	"ping-no-semicol.php":"http://localhost:9000/ping-no-semicol.php?host=localhost",
	"ping-no-space.php":"http://localhost:9000/ping-no-space.php?host=localhost",
	"ping-escapeshellcmd.php":"http://localhost:9000/ping-escapeshellcmd.php?host=localhost",
	"find-escapeshellcmd.php":"http://localhost:9000/find-escapeshellcmd.php?input=ping.php"
}


# Define the commands to test for command injection
commands = {
    'semicolon': ';whoami',
    'semicolon_with_start_space': ' ;whoami',
    'semicolon_with_end_space': '; whoami',
    'ampersand': '&whoami',
    'ampersand_with_start_space': ' &whoami',
    'ampersand_with_end_space': '& whoami',
    'logical AND': '&&whoami',
    'pipe': '|whoami',
    'pipe_with_start_space': ' |whoami',
    'pipe_with_end_space': '| whoami',
    'logical OR': '||whoami',
    'logical OR_with_start_space': ' ||whoami',
    'logical OR_with_end_space': '|| whoami',
    'subshell': '$(whoami)',
    'Argument injection': ' -exec whoami ;'
  
    }

# Define a function to test a single page
def test_page(add,url):
    # Send a GET request to the page
    response = requests.get(url)

    # Check if the response code indicates success
    if response.status_code == 200:
        print("\n{} {}".format("\u2705", add+"\n"))
    else:
        print("\n{} {}".format("\u274c" , add+"\n"))
   
    # Check for command injection vulnerabilities
    for name,command in commands.items():
        payload = "%s%s" % (url, command)
        response = requests.get(payload)
        	
        if "zeeshan" in response.text:
            print("{} {}".format("\u274c", name))
        else:
            print("{} {}".format("\u2705" , name))

def no_output(cmd,url):
	# Send a GET request to the page
    response = requests.get(url)

    # Check if the response code indicates success
    if response.status_code == 200:
        print("\n{} {}".format("\u2705", cmd))
    else:
        print("\n{} {}".format("\u274c" , cmd))

    # Check for command injection vulnerabilities

    for name,command in commands.items():
        payload = "%s%s" % (url, command+" > output.txt")
        response = requests.get(payload)
        f=open("output.txt","r")
	
	
        if "zeeshan" in f.read():
            print("{} {}".format("\u274c", name))
        else:
            print("{} {}".format("\u2705" , name))

     

# Test each page
for add,page in pages.items():
    test_page(add,page)
no_output("ping-no-output.php","http://localhost:9000/ping-no-output.php?host=localhost")

