def test_this_always_succeeds():
    assert True

def test_this_always_fails():
    assert False

def test_true_by_default():
	number = 4  # Example number
	assert number % 2 == 0
	
