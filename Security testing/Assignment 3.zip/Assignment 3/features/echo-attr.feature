Feature: Reflected XSS vulnerability testing

	Scenario: Baseline scenario echo-attr.php
		Given I visit the echo-attr.php
		When we provides a valid name parameter as zeeshan to echo-attr.php
		Then the echo-attr.php should be reachable
		And the echo-attr.php should display "Welcome user!" 
		
	
	Scenario: Malicious scenario echo-attr.php
		Given I visit the echo-attr.php
		When I inject a malicious script tag in the name parameter of URL echo-attr.php
		Then the echo-attr.php should show an alert
		When run selenium for echo-attr.php
		Then Check is the echo-attr.php is Vulnerable
	
		
		
	
