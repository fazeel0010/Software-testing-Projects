Feature: Reflected XSS vulnerability testing

	Scenario: Baseline scenario echo-name.php
		Given I visit the echo-name.php
		When we provides a valid name parameter as zeeshan to echo-name.php
		Then the echo-name.php should be reachable
		And the echo-name.php should display "Welcome user!" 
		
	
	Scenario: Malicious scenario echo-name.php
		Given I visit the echo-name.php
		When I inject a malicious script tag in the name parameter of URL echo-name.php
		Then the echo-name.php should show an alert
		When run selenium for echo-name.php
		Then Check is the echo-name.php is Vulnerable
	
		
		
	
