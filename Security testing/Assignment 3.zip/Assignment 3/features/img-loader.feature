Feature: Reflected XSS vulnerability testing

	Scenario: Baseline scenario img-loader.php
		Given I visit the img-loader.php
		When we provides a valid target parameter as zeeshan to img-loader.php
		Then the img-loader.php should be reachable
		And the img-loader.php should display "Welcome user!" 
		
	
	Scenario: Malicious scenario img-loader.php
		Given I visit the img-loader.php
		When I inject a malicious script tag in the target parameter of URL img-loader.php
		Then the img-loader.php should show an alert
		When run selenium for img-loader.php
		Then Check is the img-loader.php is Vulnerable
	
		
		
	
