Feature: Reflected XSS vulnerability testing

	Scenario: Baseline scenario img-loader-protected2.php
		Given I visit the img-loader-protected2.php
		When we provides a valid target parameter as zeeshan to img-loader-protected2.php
		Then the img-loader-protected2.php should be reachable
		And the img-loader-protected2.php should display "Welcome user!" 
		
	
	Scenario: Malicious scenario img-loader-protected2.php
		Given I visit the img-loader-protected2.php
		When I inject a malicious script tag in the target parameter of URL img-loader-protected2.php
		Then the img-loader-protected2.php should show an alert
		When run selenium for img-loader-protected2.php
		Then Check is the img-loader-protected2.php is Vulnerable
	
		
		
	
