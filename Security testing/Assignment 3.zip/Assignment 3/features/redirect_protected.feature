Feature: Reflected XSS vulnerability testing

	Scenario: Baseline scenario redirect_protected.php
		Given I visit the redirect_protected.php
		When we provides a valid target parameter as zeeshan to redirect_protected.php
		Then the redirect_protected.php should be reachable
		And the redirect_protected.php should display "zeeshan" 
		
	
	Scenario: Malicious scenario redirect_protected.php
		Given I visit the redirect_protected.php
		When I inject a malicious script tag in the target parameter of URL redirect_protected.php
		Then the redirect_protected.php should show an alert
		When run selenium for redirect_protected.php
		Then Check is the redirect_protected.php is Vulnerable
	
		
		
	
