Feature: Reflected XSS vulnerability testing

	Scenario: Baseline scenario echo-attr2.php
		Given I visit the echo-attr2.php
		When we provides a valid name parameter as zeeshan to echo-attr2.php
		Then the echo-attr2.php should be reachable
		And the echo-attr2.php should display "Welcome user!" 
		
	
	Scenario: Malicious scenario echo-attr2.php
		Given I visit the echo-attr2.php
		When I inject a malicious script tag in the name parameter of URL echo-attr2.php
		Then the echo-attr2.php should show an alert
		When run selenium for echo-attr2.php
		Then Check is the echo-attr2.php is Vulnerable
	
		
		
	
