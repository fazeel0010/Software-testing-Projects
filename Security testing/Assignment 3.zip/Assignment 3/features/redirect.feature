Feature: Reflected XSS vulnerability testing

	Scenario: Baseline scenario redirect.php
		Given I visit the redirect.php
		When we provides a valid target parameter as zeeshan to redirect.php
		Then the redirect.php should be reachable
		And the redirect.php should display "zeeshan" 
		
	
	Scenario: Malicious scenario redirect.php
		Given I visit the redirect.php
		When I inject a malicious script tag in the target parameter of URL redirect.php
		Then the redirect.php should show an alert
		When run selenium for redirect.php
		Then Check is the redirect.php is Vulnerable
	
		
		
	
