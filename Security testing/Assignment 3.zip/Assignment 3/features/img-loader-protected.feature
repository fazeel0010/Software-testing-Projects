Feature: Reflected XSS vulnerability testing

	Scenario: Baseline scenario img-loader-protected.php
		Given I visit the img-loader-protected.php
		When we provides a valid target parameter as zeeshan to img-loader-protected.php
		Then the img-loader-protected.php should be reachable
		And the img-loader-protected.php should display "Welcome user!" 
		
	
	Scenario: Malicious scenario img-loader-protected.php
		Given I visit the img-loader-protected.php
		When I inject a malicious script tag in the target parameter of URL img-loader-protected.php
		Then the img-loader-protected.php should show an alert
		When run selenium for img-loader-protected.php
		Then Check is the img-loader-protected.php is Vulnerable
	
		
		
	
