import requests
import sys
from behave import *
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC 
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import ui
from selenium import webdriver
@given('I visit the echo-name.php')
def step_impl(context):
	context.url="http://localhost:4000/echo-name.php"
	

@when('we provides a valid name parameter as zeeshan to echo-name.php')
def step_impl(context):
    	context.url="http://localhost:4000/echo-name.php?name=zeeshan"
    	context.r = requests.get(context.url)

@then(u'the echo-name.php should be reachable')
def step_impl(context):
	if context.r.status_code == 200:
		assert True;
	else: 
		assert False



@then('the echo-name.php should display "Welcome user!"')
def step_impl(context):

	if context.r.status_code == 200:
		if "Welcome" in str(context.r.text):
			assert True;
		else:
			assert False;
	else: 
		assert False



@when('I inject a malicious script tag in the name parameter of URL echo-name.php')
def step_impl(context):
	url="http://localhost:4000/echo-name.php?name=zeeshan"
	attack = '/"><script>alert(1);</script>'
	finalUrl = url + attack

	r = requests.get(finalUrl)
	
	context.response=r.text
	context.url = finalUrl

@then('the echo-name.php should show an alert')
def step_impl(context):
	output = "<script>alert(1);</script>"
	if output in context.response:
		context.isAttackable = True
		assert True
	else:
		assert False


@when('run selenium for echo-name.php')
def step_impl(context):
	context.driver=webdriver.Firefox()
	context.driver.get(context.url)
	
	try:
	#Wait for alert to be appeared
		WebDriverWait(context.driver, 3).until(EC.alert_is_present(),
				           'Timed out waiting for PA creation ' +
				           'confirmation popup to appear.')
		#Click on alert
		alert = context.driver.switch_to.alert
		alert.accept()
		context.status = True
		#Close the browser
		context.driver.quit()
	except TimeoutException:
		context.driver.quit()
		context.status = False


@then('Check is the echo-name.php is Vulnerable')
def step_impl(context):
	assert context.status

