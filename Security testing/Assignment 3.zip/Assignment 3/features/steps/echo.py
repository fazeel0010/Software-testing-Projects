import requests
import sys
from behave import *

@given('I visit the echo.php')
def step_impl(context):
	context.url="http://localhost:4000/echo.php"
    

    

@then('the echo.php should be reachable')
def step_impl(context):
	context.r = requests.get(context.url)
	if context.r.status_code != 200:
       		assert False



@then('I should see the welcome message "Welcome"')
def step_impl(context):
	if "Welcome" in str(context.r.text):
		assert True;
	else:
		assert False;




