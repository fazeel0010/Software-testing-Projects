Feature: Welcome Message Display
	
	
	Scenario: Displaying the welcome message
		Given I visit the echo.php 
		Then the echo.php should be reachable
		And I should see the welcome message "Welcome"
		
