Feature: Reflected XSS vulnerability testing

	Scenario: Baseline scenario echo-name-protected.php
		Given I visit the echo-name-protected.php
		When we provides a valid name parameter as zeeshan to echo-name-protected.php
		Then the echo-name-protected.php should be reachable
		And the echo-name-protected.php should display "Welcome user!" 
		
	
	Scenario: Malicious scenario echo-name-protected.php
		Given I visit the echo-name-protected.php
		When I inject a malicious script tag in the name parameter of URL echo-name-protected.php
		Then the echo-name-protected.php should show an alert
		When run selenium for echo-name-protected.php
		Then Check is the echo-name-protected.php is Vulnerable
	
		
		
	
